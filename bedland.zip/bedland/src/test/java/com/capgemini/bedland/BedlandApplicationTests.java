package com.capgemini.bedland;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BedlandApplicationTests {

	@Test
	void contextLoads() {
	}

}
